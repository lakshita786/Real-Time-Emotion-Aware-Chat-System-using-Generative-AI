-- Create OTP sessions table for managing temporary chat connections
CREATE TABLE IF NOT EXISTS public.otp_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  otp_code TEXT NOT NULL UNIQUE,
  user1_id TEXT,
  user2_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '5 minutes'),
  is_active BOOLEAN DEFAULT true
);

-- Create messages table for real-time chat
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES public.otp_sessions(id) ON DELETE CASCADE,
  sender_id TEXT NOT NULL,
  message_text TEXT NOT NULL,
  emotion TEXT,
  emotion_confidence DECIMAL(3,2),
  is_ai_response BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_otp_sessions_code ON public.otp_sessions(otp_code);
CREATE INDEX IF NOT EXISTS idx_otp_sessions_expires ON public.otp_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_messages_session ON public.messages(session_id);
CREATE INDEX IF NOT EXISTS idx_messages_created ON public.messages(created_at);

-- Enable Row Level Security
ALTER TABLE public.otp_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- RLS Policies for otp_sessions (allow public access for OTP-based connections)
CREATE POLICY "Anyone can create OTP sessions"
  ON public.otp_sessions FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can read active sessions"
  ON public.otp_sessions FOR SELECT
  USING (is_active = true AND expires_at > now());

CREATE POLICY "Users can update their sessions"
  ON public.otp_sessions FOR UPDATE
  USING (user1_id = current_setting('request.jwt.claims', true)::json->>'sub' 
         OR user2_id = current_setting('request.jwt.claims', true)::json->>'sub');

-- RLS Policies for messages (public read/write for session participants)
CREATE POLICY "Anyone can insert messages"
  ON public.messages FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can read messages in active sessions"
  ON public.messages FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.otp_sessions 
      WHERE id = messages.session_id 
      AND is_active = true 
      AND expires_at > now()
    )
  );

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

-- Function to clean up expired sessions
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE public.otp_sessions
  SET is_active = false
  WHERE expires_at < now() AND is_active = true;
END;
$$;