-- Fix search path for cleanup function
DROP FUNCTION IF EXISTS cleanup_expired_sessions();

CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE otp_sessions
  SET is_active = false
  WHERE expires_at < now() AND is_active = true;
END;
$$;