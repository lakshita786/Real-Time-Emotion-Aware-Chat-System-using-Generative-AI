import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Key, Users } from 'lucide-react';

interface OTPConnectionProps {
  onConnect: (sessionId: string, userId: string) => void;
}

const OTPConnection = ({ onConnect }: OTPConnectionProps) => {
  const [otpCode, setOtpCode] = useState('');
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  const generateOTP = async () => {
    setIsGenerating(true);
    try {
      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const userId = crypto.randomUUID();

      // Create session in database
      const { data, error } = await supabase
        .from('otp_sessions')
        .insert({
          otp_code: otp,
          user1_id: userId,
        })
        .select()
        .single();

      if (error) throw error;

      setGeneratedOTP(otp);
      toast({
        title: 'OTP Generated!',
        description: `Share this code with your chat partner: ${otp}`,
      });

      // Auto-connect as user1
      onConnect(data.id, userId);
    } catch (error) {
      console.error('Error generating OTP:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate OTP. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const connectWithOTP = async () => {
    if (!otpCode || otpCode.length !== 6) {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter a valid 6-digit OTP code.',
        variant: 'destructive',
      });
      return;
    }

    setIsConnecting(true);
    try {
      const userId = crypto.randomUUID();

      // Find session with OTP
      const { data: session, error: findError } = await supabase
        .from('otp_sessions')
        .select('*')
        .eq('otp_code', otpCode)
        .eq('is_active', true)
        .gt('expires_at', new Date().toISOString())
        .single();

      if (findError || !session) {
        throw new Error('Invalid or expired OTP code');
      }

      // Check if session already has user2
      if (session.user2_id) {
        throw new Error('This OTP is already in use');
      }

      // Update session with user2
      const { error: updateError } = await supabase
        .from('otp_sessions')
        .update({ user2_id: userId })
        .eq('id', session.id);

      if (updateError) throw updateError;

      toast({
        title: 'Connected!',
        description: 'You are now connected to the chat.',
      });

      onConnect(session.id, userId);
    } catch (error: any) {
      console.error('Error connecting with OTP:', error);
      toast({
        title: 'Connection Failed',
        description: error.message || 'Failed to connect with OTP. Please check the code and try again.',
        variant: 'destructive',
      });
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--gradient-bg)' }}>
      <Card className="w-full max-w-md shadow-[var(--shadow-card)]" style={{ background: 'var(--gradient-card)' }}>
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-4 rounded-full bg-primary/10" style={{ boxShadow: 'var(--shadow-glow)' }}>
              <Users className="w-12 h-12 text-primary" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Emotion Chat
          </CardTitle>
          <CardDescription className="text-base">
            Connect with someone using a secure OTP code
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Button
              onClick={generateOTP}
              disabled={isGenerating || generatedOTP !== ''}
              className="w-full h-12 text-lg font-semibold transition-all hover:scale-105"
              style={{ boxShadow: 'var(--shadow-glow)' }}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Key className="mr-2 h-5 w-5" />
                  Generate OTP Code
                </>
              )}
            </Button>

            {generatedOTP && (
              <div className="p-4 rounded-lg bg-primary/10 border-2 border-primary/20 text-center animate-in fade-in slide-in-from-bottom-4">
                <p className="text-sm text-muted-foreground mb-1">Your OTP Code</p>
                <p className="text-4xl font-bold tracking-wider text-primary">{generatedOTP}</p>
                <p className="text-xs text-muted-foreground mt-2">Share this with your chat partner</p>
              </div>
            )}
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">Or enter existing code</span>
            </div>
          </div>

          <div className="space-y-3">
            <Input
              type="text"
              placeholder="Enter 6-digit OTP"
              value={otpCode}
              onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
              maxLength={6}
              className="h-12 text-center text-2xl tracking-widest font-mono"
              disabled={isConnecting}
            />
            <Button
              onClick={connectWithOTP}
              disabled={isConnecting || otpCode.length !== 6}
              variant="secondary"
              className="w-full h-12 text-lg font-semibold"
            >
              {isConnecting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Connecting...
                </>
              ) : (
                'Connect to Chat'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OTPConnection;
