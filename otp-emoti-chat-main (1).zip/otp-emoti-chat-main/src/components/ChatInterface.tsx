import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Send, Loader2, Bot, LogOut, Sparkles } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

interface Message {
  id: string;
  sender_id: string;
  message_text: string;
  emotion: string | null;
  emotion_confidence: number | null;
  is_ai_response: boolean;
  created_at: string;
}

interface ChatInterfaceProps {
  sessionId: string;
  userId: string;
  onDisconnect: () => void;
}

const emotionColors: Record<string, string> = {
  happy: 'hsl(var(--emotion-happy))',
  sad: 'hsl(var(--emotion-sad))',
  angry: 'hsl(var(--emotion-angry))',
  surprised: 'hsl(var(--emotion-surprised))',
  neutral: 'hsl(var(--emotion-neutral))',
  fear: 'hsl(var(--emotion-fear))',
};

const emotionEmojis: Record<string, string> = {
  happy: '😊',
  sad: '😢',
  angry: '😡',
  surprised: '😮',
  neutral: '😐',
  fear: '😰',
};

const ChatInterface = ({ sessionId, userId, onDisconnect }: ChatInterfaceProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [aiMode, setAiMode] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Fetch existing messages
    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('session_id', sessionId)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching messages:', error);
        return;
      }

      setMessages(data || []);
    };

    fetchMessages();

    // Subscribe to new messages
    const channel = supabase
      .channel('messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `session_id=eq.${sessionId}`,
        },
        (payload) => {
          setMessages((current) => [...current, payload.new as Message]);
          setIsTyping(false);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [sessionId]);

  const analyzeEmotion = async (text: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('analyze-emotion', {
        body: { message: text },
      });

      if (error) throw error;
      return data;
    } catch (error: any) {
      console.error('Error analyzing emotion:', error);
      if (error.message?.includes('429') || error.message?.includes('rate limit')) {
        toast({
          title: 'Rate Limited',
          description: 'AI emotion detection temporarily unavailable. Message sent without emotion analysis.',
          variant: 'destructive',
        });
      }
      return { emotion: 'neutral', confidence: 0.5 };
    }
  };

  const generateAIResponse = async (userMessage: string, emotion: string) => {
    try {
      setIsTyping(true);
      const { data, error } = await supabase.functions.invoke('generate-ai-response', {
        body: { message: userMessage, emotion },
      });

      if (error) throw error;

      // Analyze AI response emotion
      const aiEmotion = await analyzeEmotion(data.message);

      // Save AI response to database
      const { error: insertError } = await supabase.from('messages').insert({
        session_id: sessionId,
        sender_id: 'ai-assistant',
        message_text: data.message,
        emotion: aiEmotion.emotion,
        emotion_confidence: aiEmotion.confidence,
        is_ai_response: true,
      });

      if (insertError) throw insertError;
    } catch (error: any) {
      console.error('Error generating AI response:', error);
      setIsTyping(false);
      if (error.message?.includes('429') || error.message?.includes('rate limit')) {
        toast({
          title: 'Rate Limited',
          description: 'AI assistant temporarily unavailable. Please try again in a moment.',
          variant: 'destructive',
        });
      }
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || isSending) return;

    setIsSending(true);
    const messageText = inputMessage.trim();
    setInputMessage('');

    try {
      // Analyze emotion
      const emotionData = await analyzeEmotion(messageText);

      // Save message to database
      const { error } = await supabase.from('messages').insert({
        session_id: sessionId,
        sender_id: userId,
        message_text: messageText,
        emotion: emotionData.emotion,
        emotion_confidence: emotionData.confidence,
        is_ai_response: false,
      });

      if (error) throw error;

      // Generate AI response if AI mode is enabled
      if (aiMode) {
        await generateAIResponse(messageText, emotionData.emotion);
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--gradient-bg)' }}>
      {/* Header */}
      <div className="bg-card border-b shadow-md p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-full bg-primary/10">
              <Sparkles className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Emotion Chat</h1>
              <p className="text-sm text-muted-foreground">Session Active</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Switch
                id="ai-mode"
                checked={aiMode}
                onCheckedChange={setAiMode}
              />
              <Label htmlFor="ai-mode" className="flex items-center gap-1 cursor-pointer">
                <Bot className="w-4 h-4" />
                <span className="text-sm">AI Assistant</span>
              </Label>
            </div>
            <Button variant="outline" size="sm" onClick={onDisconnect}>
              <LogOut className="w-4 h-4 mr-2" />
              Disconnect
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((msg) => {
            const isOwn = msg.sender_id === userId;
            const emotion = msg.emotion || 'neutral';
            const emotionColor = emotionColors[emotion] || emotionColors.neutral;

            return (
              <div
                key={msg.id}
                className={`flex ${isOwn ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}
              >
                <Card
                  className={`max-w-[70%] p-4 ${isOwn ? 'bg-primary text-primary-foreground' : 'bg-card'}`}
                  style={
                    !isOwn
                      ? { borderLeft: `4px solid ${emotionColor}` }
                      : { boxShadow: 'var(--shadow-glow)' }
                  }
                >
                  {msg.is_ai_response && (
                    <div className="flex items-center gap-2 mb-2 text-xs opacity-70">
                      <Bot className="w-3 h-3" />
                      <span>AI Assistant</span>
                    </div>
                  )}
                  <p className="text-sm break-words">{msg.message_text}</p>
                  <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                    <div className="flex items-center gap-2">
                      <span>{emotionEmojis[emotion]}</span>
                      <span className="capitalize">{emotion}</span>
                      {msg.emotion_confidence && (
                        <span>({Math.round(msg.emotion_confidence * 100)}%)</span>
                      )}
                    </div>
                    <span>{new Date(msg.created_at).toLocaleTimeString()}</span>
                  </div>
                </Card>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex justify-start animate-in slide-in-from-bottom-2">
              <Card className="p-4 bg-card">
                <div className="flex items-center gap-2">
                  <Bot className="w-4 h-4 text-primary" />
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  </div>
                </div>
              </Card>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="bg-card border-t shadow-lg p-4">
        <div className="max-w-4xl mx-auto flex gap-2">
          <Input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="Type your message..."
            disabled={isSending}
            className="h-12"
          />
          <Button
            onClick={sendMessage}
            disabled={isSending || !inputMessage.trim()}
            className="h-12 px-6"
            style={{ boxShadow: 'var(--shadow-glow)' }}
          >
            {isSending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
