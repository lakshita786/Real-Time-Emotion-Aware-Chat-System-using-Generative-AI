import { useState } from 'react';
import OTPConnection from '@/components/OTPConnection';
import ChatInterface from '@/components/ChatInterface';

const Index = () => {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);

  const handleConnect = (newSessionId: string, newUserId: string) => {
    setSessionId(newSessionId);
    setUserId(newUserId);
  };

  const handleDisconnect = () => {
    setSessionId(null);
    setUserId(null);
  };

  return (
    <>
      {!sessionId || !userId ? (
        <OTPConnection onConnect={handleConnect} />
      ) : (
        <ChatInterface
          sessionId={sessionId}
          userId={userId}
          onDisconnect={handleDisconnect}
        />
      )}
    </>
  );
};

export default Index;
